def red(string):
	return "\033[0;31mfailed\033[0m".format(str)

def green(str):
	return "\033[0;32m{}\033[0m".format(str)

def yellow(str):
	return "\033[0;33m{}\033[0m".format(str)
