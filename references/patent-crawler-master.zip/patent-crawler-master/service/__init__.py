# -*- coding: utf-8 -*-
"""
Created on 2017/3/24

@author: will4906
"""
# from logbook import Logger

# from service import log
# # # from service.account import *
# # # from service.proxy import *
# #
# # logger = Logger('main')
# #
# # if __name__ == '__main__':
# #     # stupid()
# #     # update_proxy()
# #     # notify_ip_address()
# #     # update_cookies()
# from service.account import login
#
# login()