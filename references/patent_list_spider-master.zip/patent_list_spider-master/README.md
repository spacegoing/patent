# patent_list_spider
通过http://www.pss-system.gov.cn/爬取中国专利列表



使用方法： 1、用谷歌浏览器登录专利查询网站http://www.pss-system.gov.cn/ ，注意一定要谷歌浏览器。 

2、修改脚本中的public_date,和name_keyword,目前脚本中的搜索规则只支持公开时间>xxxxx,以及发明名称的关键字筛选（or）。 

3、运行脚本，爬取结果会写入res.txt中。想要更好体验请自行复制粘贴至excel中浏览。 

ps:需要其他搜索规则的请自行修改脚本。
![img](https://raw.githubusercontent.com/sevensun003/patent_list_spider/master/barimage.bmp)
